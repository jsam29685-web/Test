class InstitutionalLevel {
  final String id; // DO, WO, MO, QO, YO, POM, PDH, PDL, PWH, PWL, PWM, PMH, PML, PMM, MDAY-H, MDAY-M, MDAY-L
  final String name;
  final double price;
  final String description;

  InstitutionalLevel({
    required this.id,
    required this.name,
    required this.price,
    required this.description,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'price': price,
    'description': description,
  };

  factory InstitutionalLevel.fromJson(Map<String, dynamic> json) =>
      InstitutionalLevel(
        id: json['id'] as String,
        name: json['name'] as String,
        price: (json['price'] as num).toDouble(),
        description: json['description'] as String,
      );
}

class ConfluenceZone {
  final String id;
  final double low;
  final double high;
  final double mid;
  final List<InstitutionalLevel> levels;
  final int levelCount;
  final bool isStrong; // 3+ levels

  ConfluenceZone({
    required this.id,
    required this.low,
    required this.high,
    required this.mid,
    required this.levels,
    required this.levelCount,
    required this.isStrong,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'low': low,
    'high': high,
    'mid': mid,
    'levels': levels.map((l) => l.toJson()).toList(),
    'levelCount': levelCount,
    'isStrong': isStrong,
  };

  factory ConfluenceZone.fromJson(Map<String, dynamic> json) => ConfluenceZone(
    id: json['id'] as String,
    low: (json['low'] as num).toDouble(),
    high: (json['high'] as num).toDouble(),
    mid: (json['mid'] as num).toDouble(),
    levels: (json['levels'] as List)
        .map((l) => InstitutionalLevel.fromJson(l as Map<String, dynamic>))
        .toList(),
    levelCount: json['levelCount'] as int,
    isStrong: json['isStrong'] as bool,
  );
}
