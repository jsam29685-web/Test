class Candle {
  final int time; // Unix seconds
  final double open;
  final double high;
  final double low;
  final double close;
  final double volume;

  Candle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });

  factory Candle.fromCoinbase(List<dynamic> row) {
    // Coinbase format: [time, low, high, open, close, volume]
    return Candle(
      time: (row[0] as num).toInt(),
      low: (row[1] as num).toDouble(),
      high: (row[2] as num).toDouble(),
      open: (row[3] as num).toDouble(),
      close: (row[4] as num).toDouble(),
      volume: (row[5] as num).toDouble(),
    );
  }

  factory Candle.fromBinance(List<dynamic> row) {
    // Binance format: [openTime, open, high, low, close, volume, ...]
    return Candle(
      time: ((row[0] as num).toInt() ~/ 1000),
      open: double.parse(row[1].toString()),
      high: double.parse(row[2].toString()),
      low: double.parse(row[3].toString()),
      close: double.parse(row[4].toString()),
      volume: double.parse(row[5].toString()),
    );
  }

  Map<String, dynamic> toJson() => {
    'time': time,
    'open': open,
    'high': high,
    'low': low,
    'close': close,
    'volume': volume,
  };

  factory Candle.fromJson(Map<String, dynamic> json) => Candle(
    time: json['time'] as int,
    open: (json['open'] as num).toDouble(),
    high: (json['high'] as num).toDouble(),
    low: (json['low'] as num).toDouble(),
    close: (json['close'] as num).toDouble(),
    volume: (json['volume'] as num).toDouble(),
  );
}
