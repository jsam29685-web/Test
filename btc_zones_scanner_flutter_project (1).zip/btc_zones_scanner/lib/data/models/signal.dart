class TradeSignal {
  final String id;
  final String direction; // 'BUY' or 'SELL'
  final String setupType; // 'REVERSAL' or 'BREAKOUT'
  final double entryPrice;
  final double stopLoss;
  final double takeProfit;
  final double riskReward;
  final List<String> zoneLevels;
  final bool isStrongZone;
  final double atr;
  final int timestamp;
  final List<String> reasoning;

  TradeSignal({
    required this.id,
    required this.direction,
    required this.setupType,
    required this.entryPrice,
    required this.stopLoss,
    required this.takeProfit,
    required this.riskReward,
    required this.zoneLevels,
    required this.isStrongZone,
    required this.atr,
    required this.timestamp,
    required this.reasoning,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'direction': direction,
    'setupType': setupType,
    'entryPrice': entryPrice,
    'stopLoss': stopLoss,
    'takeProfit': takeProfit,
    'riskReward': riskReward,
    'zoneLevels': zoneLevels,
    'isStrongZone': isStrongZone,
    'atr': atr,
    'timestamp': timestamp,
    'reasoning': reasoning,
  };

  factory TradeSignal.fromJson(Map<String, dynamic> json) => TradeSignal(
    id: json['id'] as String,
    direction: json['direction'] as String,
    setupType: json['setupType'] as String,
    entryPrice: (json['entryPrice'] as num).toDouble(),
    stopLoss: (json['stopLoss'] as num).toDouble(),
    takeProfit: (json['takeProfit'] as num).toDouble(),
    riskReward: (json['riskReward'] as num).toDouble(),
    zoneLevels: List<String>.from(json['zoneLevels'] as List),
    isStrongZone: json['isStrongZone'] as bool,
    atr: (json['atr'] as num).toDouble(),
    timestamp: json['timestamp'] as int,
    reasoning: List<String>.from(json['reasoning'] as List),
  );
}
