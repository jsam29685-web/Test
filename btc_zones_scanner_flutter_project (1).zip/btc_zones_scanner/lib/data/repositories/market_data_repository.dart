import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import '../../core/constants/trading_constants.dart';
import '../models/candle.dart';

class MarketDataRepository {
  final Dio _dio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 8),
      receiveTimeout: const Duration(seconds: 8),
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'BTC-Zones-Scanner/1.0',
      },
    ),
  );

  /// Fetches 15-minute BTC-USD candles from Coinbase with Binance fallback
  Future<List<Candle>> fetch15mCandles() async {
    // 1. Primary: Coinbase Exchange
    try {
      final response = await _dio.get(TradingConstants.coinbaseCandlesUrl);
      if (response.statusCode == 200 && response.data is List) {
        final rawList = response.data as List;
        final candles = rawList.map((row) => Candle.fromCoinbase(row as List)).toList();

        // Coinbase returns newest first; sort ascending
        candles.sort((a, b) => a.time.compareTo(b.time));

        // Drop the current live unclosed candle (ensure ONLY fully closed candles)
        if (candles.length > 20) {
          return candles.sublist(0, candles.length - 1);
        }
      }
    } catch (e) {
      debugPrint('Coinbase fetch failed, falling back to Binance: $e');
    }

    // 2. Fallback: Binance klines
    try {
      final response = await _dio.get(TradingConstants.binanceKlinesUrl);
      if (response.statusCode == 200 && response.data is List) {
        final rawList = response.data as List;
        final candles = rawList.map((row) => Candle.fromBinance(row as List)).toList();

        // Drop unclosed candle
        if (candles.length > 20) {
          return candles.sublist(0, candles.length - 1);
        }
      }
    } catch (e) {
      debugPrint('Binance fallback failed: $e');
    }

    return [];
  }
}
