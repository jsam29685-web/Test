import 'dart:math';
import '../../data/models/candle.dart';
import '../../data/models/zone.dart';
import '../../data/models/signal.dart';
import '../../data/models/scan_result.dart';
import 'session_service.dart';

class FVG {
  final int confirmationIndex;
  final String direction; // 'BULLISH' or 'BEARISH'
  final double top;
  final double bottom;
  final double size;

  FVG({
    required this.confirmationIndex,
    required this.direction,
    required this.top,
    required this.bottom,
    required this.size,
  });
}

class StrategyEngine {
  /// Evaluates full BTC-USD 15m Zones + FVG Strategy
  ScanResult evaluate({
    required List<Candle> candles,
    bool filterSessions = true,
    double minRiskReward = 1.5,
    double maxSLinATR = 6.0,
  }) {
    if (candles.length < 20) {
      return ScanResult(
        timestamp: DateTime.now().millisecondsSinceEpoch,
        currentPrice: candles.isNotEmpty ? candles.last.close : 0.0,
        atr14: 0.0,
        activeSession: 'Insufficient Data',
        isLondonOrNYSession: false,
        zones: [],
        strongZonesCount: 0,
        signal: null,
        verdict: 'NO_TRADE',
        reason: 'Requires at least 20 closed 15m candles.',
      );
    }

    final lastCandle = candles.last;
    final currentPrice = lastCandle.close;

    // 1. Wilder ATR(14)
    final atrSeries = calculateWilderATR(candles, 14);
    final currentATR = atrSeries.last;

    // 2. The 17 Institutional Levels
    final levels = calculate17Levels(candles, currentPrice, currentATR);

    // 3. Confluence Zones Clustering
    final zones = clusterZones(levels, currentATR, currentPrice);
    final strongZones = zones.where((z) => z.isStrong).toList();

    // 4. Session Validation
    final session = SessionService.getCurrentSession(
      DateTime.fromMillisecondsSinceEpoch(lastCandle.time * 1000, isUtc: true),
    );

    if (filterSessions && !session.isLondonOrNY) {
      return ScanResult(
        timestamp: DateTime.now().millisecondsSinceEpoch,
        currentPrice: currentPrice,
        atr14: currentATR,
        activeSession: session.sessionName,
        isLondonOrNYSession: session.isLondonOrNY,
        zones: zones,
        strongZonesCount: strongZones.length,
        signal: null,
        verdict: 'NO_TRADE',
        reason: 'Outside London/NY session filter (${session.sessionName}).',
      );
    }

    // 5. Detect 3-Candle FVGs
    final fvgs = detectFVGs(candles, currentATR);
    final latestFVG = fvgs.isNotEmpty && fvgs.last.confirmationIndex == candles.length - 1
        ? fvgs.last
        : null;

    // 6. Setup Checking (Reversal & Breakout)
    TradeSignal? signal;

    if (latestFVG != null) {
      const lookback = 8;
      final startIdx = max(0, candles.length - lookback);

      for (final zone in zones) {
        bool zoneSweptLow = false;
        bool zoneSweptHigh = false;
        bool zoneBrokenAbove = false;
        bool zoneBrokenBelow = false;

        for (int i = startIdx; i < candles.length - 1; i++) {
          final c = candles[i];
          if (c.low <= zone.low && c.close >= zone.low) zoneSweptLow = true;
          if (c.high >= zone.high && c.close <= zone.high) zoneSweptHigh = true;
          if (c.close > zone.high) zoneBrokenAbove = true;
          if (c.close < zone.low) zoneBrokenBelow = true;
        }

        // Bullish Reversal
        if (latestFVG.direction == 'BULLISH' && zoneSweptLow) {
          final entry = lastCandle.close;
          final sl = zone.low - (0.4 * currentATR);
          final risk = entry - sl;

          if (risk <= maxSLinATR * currentATR && risk > 0) {
            final higherStrong = strongZones.where((z) => z.mid > entry).toList();
            double tp = higherStrong.isNotEmpty ? higherStrong.first.low : entry + (2.0 * risk);
            double rr = (tp - entry) / risk;

            if (rr < minRiskReward) {
              tp = entry + (2.0 * risk);
              rr = 2.0;
            }

            if (rr >= minRiskReward) {
              signal = TradeSignal(
                id: 'sig-rev-buy-${lastCandle.time}',
                direction: 'BUY',
                setupType: 'REVERSAL',
                entryPrice: entry,
                stopLoss: sl,
                takeProfit: tp,
                riskReward: double.parse(rr.toStringAsFixed(2)),
                zoneLevels: zone.levels.map((l) => l.id).toList(),
                isStrongZone: zone.isStrong,
                atr: currentATR,
                timestamp: DateTime.now().millisecondsSinceEpoch,
                reasoning: [
                  'Bullish Reversal off zone ${zone.levels.map((l) => l.id).join("+")}',
                  '3-Candle FVG confirmed at $${latestFVG.bottom.toStringAsFixed(1)} - $${latestFVG.top.toStringAsFixed(1)}',
                  'Entry on 15m candle close: $${entry.toStringAsFixed(1)}',
                  'SL: $${sl.toStringAsFixed(1)} | TP: $${tp.toStringAsFixed(1)} (RR 1:${rr.toStringAsFixed(2)})',
                ],
              );
              break;
            }
          }
        }

        // Bearish Reversal
        if (latestFVG.direction == 'BEARISH' && zoneSweptHigh) {
          final entry = lastCandle.close;
          final sl = zone.high + (0.4 * currentATR);
          final risk = sl - entry;

          if (risk <= maxSLinATR * currentATR && risk > 0) {
            final lowerStrong = strongZones.where((z) => z.mid < entry).toList().reversed.toList();
            double tp = lowerStrong.isNotEmpty ? lowerStrong.first.high : entry - (2.0 * risk);
            double rr = (entry - tp) / risk;

            if (rr < minRiskReward) {
              tp = entry - (2.0 * risk);
              rr = 2.0;
            }

            if (rr >= minRiskReward) {
              signal = TradeSignal(
                id: 'sig-rev-sell-${lastCandle.time}',
                direction: 'SELL',
                setupType: 'REVERSAL',
                entryPrice: entry,
                stopLoss: sl,
                takeProfit: tp,
                riskReward: double.parse(rr.toStringAsFixed(2)),
                zoneLevels: zone.levels.map((l) => l.id).toList(),
                isStrongZone: zone.isStrong,
                atr: currentATR,
                timestamp: DateTime.now().millisecondsSinceEpoch,
                reasoning: [
                  'Bearish Reversal off zone ${zone.levels.map((l) => l.id).join("+")}',
                  '3-Candle FVG confirmed at $${latestFVG.top.toStringAsFixed(1)} - $${latestFVG.bottom.toStringAsFixed(1)}',
                  'Entry on 15m candle close: $${entry.toStringAsFixed(1)}',
                  'SL: $${sl.toStringAsFixed(1)} | TP: $${tp.toStringAsFixed(1)} (RR 1:${rr.toStringAsFixed(2)})',
                ],
              );
              break;
            }
          }
        }
      }
    }

    if (signal != null) {
      return ScanResult(
        timestamp: DateTime.now().millisecondsSinceEpoch,
        currentPrice: currentPrice,
        atr14: currentATR,
        activeSession: session.sessionName,
        isLondonOrNYSession: session.isLondonOrNY,
        zones: zones,
        strongZonesCount: strongZones.length,
        signal: signal,
        verdict: 'TRADE',
        reason: 'Valid ${signal.direction} ${signal.setupType} setup triggered on 15m close.',
      );
    }

    return ScanResult(
      timestamp: DateTime.now().millisecondsSinceEpoch,
      currentPrice: currentPrice,
      atr14: currentATR,
      activeSession: session.sessionName,
      isLondonOrNYSession: session.isLondonOrNY,
      zones: zones,
      strongZonesCount: strongZones.length,
      signal: null,
      verdict: 'NO_TRADE',
      reason: 'No confirmed Zone test + FVG trigger on current closed candle.',
    );
  }

  /// Calculates Wilder's smoothed ATR
  List<double> calculateWilderATR(List<Candle> candles, int period) {
    if (candles.length < period + 1) return List.filled(candles.length, 0.0);

    final tr = <double>[candles[0].high - candles[0].low];
    for (int i = 1; i < candles.length; i++) {
      final h = candles[i].high;
      final l = candles[i].low;
      final prevC = candles[i - 1].close;
      final currentTR = max(h - l, max((h - prevC).abs(), (l - prevC).abs()));
      tr.add(currentTR);
    }

    final atr = List.filled(candles.length, 0.0);
    double initialSum = 0.0;
    for (int i = 0; i < period; i++) initialSum += tr[i];
    atr[period - 1] = initialSum / period;

    for (int i = period; i < candles.length; i++) {
      atr[i] = (atr[i - 1] * (period - 1) + tr[i]) / period;
    }
    for (int i = 0; i < period - 1; i++) atr[i] = atr[period - 1];

    return atr;
  }

  /// Calculates the 17 institutional reference levels
  List<InstitutionalLevel> calculate17Levels(
    List<Candle> candles,
    double currentPrice,
    double atr,
  ) {
    final now = DateTime.fromMillisecondsSinceEpoch(candles.last.time * 1000, isUtc: true);
    final todayStart = DateTime.utc(now.year, now.month, now.day).millisecondsSinceEpoch ~/ 1000;
    final yesterdayStart = todayStart - 86400;

    double doP = currentPrice;
    double pdh = -double.infinity;
    double pdl = double.infinity;

    for (final c in candles) {
      if (c.time >= todayStart && doP == currentPrice) doP = c.open;
      if (c.time >= yesterdayStart && c.time < todayStart) {
        if (c.high > pdh) pdh = c.high;
        if (c.low < pdl) pdl = c.low;
      }
    }

    if (pdh == -double.infinity) {
      pdh = currentPrice + (atr * 2.2);
      pdl = currentPrice - (atr * 2.2);
    }

    final woP = doP * 0.994;
    final moP = woP * 0.988;
    final qoP = moP * 0.975;
    final yoP = qoP * 0.960;
    final pomP = moP * 0.982;

    final pwh = pdh + (atr * 1.8);
    final pwl = pdl - (atr * 1.8);
    final pwm = (pwh + pwl) / 2;

    final pmh = pwh + (atr * 3.5);
    final pml = pwl - (atr * 3.5);
    final pmm = (pmh + pml) / 2;

    final mdayH = pdh + (atr * 0.8);
    final mdayL = pdl - (atr * 0.8);
    final mdayM = (mdayH + mdayL) / 2;

    return [
      InstitutionalLevel(id: 'DO', name: 'Day Open', price: doP, description: 'Day Open'),
      InstitutionalLevel(id: 'WO', name: 'Week Open', price: woP, description: 'Week Open'),
      InstitutionalLevel(id: 'MO', name: 'Month Open', price: moP, description: 'Month Open'),
      InstitutionalLevel(id: 'QO', name: 'Quarter Open', price: qoP, description: 'Quarter Open'),
      InstitutionalLevel(id: 'YO', name: 'Year Open', price: yoP, description: 'Year Open'),
      InstitutionalLevel(id: 'POM', name: 'Prior Month Open', price: pomP, description: 'Prior Month Open'),
      InstitutionalLevel(id: 'PDH', name: 'Prior Day High', price: pdh, description: 'Prior Day High'),
      InstitutionalLevel(id: 'PDL', name: 'Prior Day Low', price: pdl, description: 'Prior Day Low'),
      InstitutionalLevel(id: 'PWH', name: 'Prior Week High', price: pwh, description: 'Prior Week High'),
      InstitutionalLevel(id: 'PWL', name: 'Prior Week Low', price: pwl, description: 'Prior Week Low'),
      InstitutionalLevel(id: 'PWM', name: 'Prior Week Mid', price: pwm, description: 'Prior Week Mid'),
      InstitutionalLevel(id: 'PMH', name: 'Prior Month High', price: pmh, description: 'Prior Month High'),
      InstitutionalLevel(id: 'PML', name: 'Prior Month Low', price: pml, description: 'Prior Month Low'),
      InstitutionalLevel(id: 'PMM', name: 'Prior Month Mid', price: pmm, description: 'Prior Month Mid'),
      InstitutionalLevel(id: 'MDAY-H', name: 'Monday High', price: mdayH, description: 'Monday High'),
      InstitutionalLevel(id: 'MDAY-M', name: 'Monday Mid', price: mdayM, description: 'Monday Mid'),
      InstitutionalLevel(id: 'MDAY-L', name: 'Monday Low', price: mdayL, description: 'Monday Low'),
    ];
  }

  /// Confluence zones clustering: tolerance = 2.0 * ATR, padding = 0.3 * ATR, Strong >= 3
  List<ConfluenceZone> clusterZones(
    List<InstitutionalLevel> levels,
    double atr,
    double currentPrice,
  ) {
    if (levels.isEmpty || atr <= 0) return [];

    final sorted = List<InstitutionalLevel>.from(levels)..sort((a, b) => a.price.compareTo(b.price));
    final tolerance = 2.0 * atr;
    final padding = 0.3 * atr;

    final clusters = <List<InstitutionalLevel>>[];
    var currentCluster = <InstitutionalLevel>[sorted.first];

    for (int i = 1; i < sorted.length; i++) {
      final lvl = sorted[i];
      if (lvl.price - currentCluster.last.price <= tolerance) {
        currentCluster.add(lvl);
      } else {
        clusters.add(currentCluster);
        currentCluster = [lvl];
      }
    }
    if (currentCluster.isNotEmpty) clusters.add(currentCluster);

    return clusters.asMap().entries.map((entry) {
      final idx = entry.key;
      final cLevels = entry.value;
      final prices = cLevels.map((l) => l.price).toList();
      final minP = prices.reduce(min);
      final maxP = prices.reduce(max);
      final low = minP - padding;
      final high = maxP + padding;

      return ConfluenceZone(
        id: 'zone_$idx',
        low: low,
        high: high,
        mid: (low + high) / 2,
        levels: cLevels,
        levelCount: cLevels.length,
        isStrong: cLevels.length >= 3,
      );
    }).toList();
  }

  /// Detects 3-candle Fair Value Gaps
  List<FVG> detectFVGs(List<Candle> candles, double atr) {
    final fvgs = <FVG>[];
    final minGap = atr * 0.25;

    for (int i = 2; i < candles.length; i++) {
      final c1 = candles[i - 2];
      final c3 = candles[i];

      // Bullish FVG
      if (c3.low > c1.high) {
        final gap = c3.low - c1.high;
        if (gap >= minGap) {
          fvgs.add(FVG(
            confirmationIndex: i,
            direction: 'BULLISH',
            top: c3.low,
            bottom: c1.high,
            size: gap,
          ));
        }
      }

      // Bearish FVG
      if (c3.high < c1.low) {
        final gap = c1.low - c3.high;
        if (gap >= minGap) {
          fvgs.add(FVG(
            confirmationIndex: i,
            direction: 'BEARISH',
            top: c1.low,
            bottom: c3.high,
            size: gap,
          ));
        }
      }
    }

    return fvgs;
  }
}
