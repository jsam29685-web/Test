import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../../data/models/signal.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  static const String tradeChannelId = 'btc_trade_signals';
  static const String tradeChannelName = 'BTC Trade Signals';
  static const String scanChannelId = 'btc_silent_scans';
  static const String scanChannelName = 'BTC Routine Scans';

  static Future<void> initialize() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidSettings);

    await _notificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (response) {
        // Handle notification click to navigate to dashboard
      },
    );

    // Create High-Priority Trade Alert Channel
    const tradeChannel = AndroidNotificationChannel(
      tradeChannelId,
      tradeChannelName,
      description: 'Instant loud alerts with vibration for valid Trade setups',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
    );

    // Create Silent Routine Scan Channel
    const scanChannel = AndroidNotificationChannel(
      scanChannelId,
      scanChannelName,
      description: 'Silent background scan status updates',
      importance: Importance.low,
      priority: Priority.low,
      playSound: false,
      enableVibration: false,
    );

    final androidImplementation = _notificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    if (androidImplementation != null) {
      await androidImplementation.createNotificationChannel(tradeChannel);
      await androidImplementation.createNotificationChannel(scanChannel);
      await androidImplementation.requestNotificationsPermission();
    }
  }

  /// High-priority alert with sound and vibration
  static Future<void> showTradeSignalNotification(TradeSignal signal) async {
    final title = '🚨 VALID ${signal.direction} SIGNAL (${signal.setupType})';
    final body =
        'Entry: $${signal.entryPrice.toStringAsFixed(1)} | '
        'SL: $${signal.stopLoss.toStringAsFixed(1)} | '
        'TP: $${signal.takeProfit.toStringAsFixed(1)} | '
        'RR: 1:${signal.riskReward.toStringAsFixed(2)}\n'
        'Zone: ${signal.zoneLevels.join(" + ")}';

    const androidDetails = AndroidNotificationDetails(
      tradeChannelId,
      tradeChannelName,
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'BTC Trade Signal Detected',
      styleInformation: BigTextStyleInformation(''),
    );

    await _notificationsPlugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      title,
      body,
      const NotificationDetails(android: androidDetails),
    );
  }

  /// Silent routine update
  static Future<void> showSilentScanNotification(String message) async {
    const androidDetails = AndroidNotificationDetails(
      scanChannelId,
      scanChannelName,
      importance: Importance.low,
      priority: Priority.low,
      silent: true,
      showWhen: true,
    );

    await _notificationsPlugin.show(
      101, // Single persistent slot for routine scans
      'BTC Zones Scanner',
      message,
      const NotificationDetails(android: androidDetails),
    );
  }
}
