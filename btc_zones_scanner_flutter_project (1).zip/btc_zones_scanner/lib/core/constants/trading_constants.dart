class TradingConstants {
  static const String appName = 'BTC Zones Scanner';
  static const String packageName = 'com.btczones.scanner';

  // Strategy Parameters
  static const int atrPeriod = 14;
  static const double zoneToleranceAtrMultiplier = 2.0;
  static const double zonePaddingAtrMultiplier = 0.3;
  static const double minAtrFvgMultiplier = 0.25;
  static const int strongZoneThreshold = 3; // 3+ levels
  static const double defaultMinRR = 1.5;
  static const double defaultMaxSLinATR = 6.0;

  // Session UTC boundaries (in minutes from 00:00 UTC)
  static const int londonStartMinute = 8 * 60; // 08:00 UTC
  static const int londonEndMinute = 16 * 60 + 30; // 16:30 UTC
  static const int newYorkStartMinute = 13 * 60; // 13:00 UTC
  static const int newYorkEndMinute = 21 * 60; // 21:00 UTC

  // API Endpoints
  static const String coinbaseCandlesUrl =
      'https://api.exchange.coinbase.com/products/BTC-USD/candles?granularity=900';
  static const String binanceKlinesUrl =
      'https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=15m&limit=300';
}
