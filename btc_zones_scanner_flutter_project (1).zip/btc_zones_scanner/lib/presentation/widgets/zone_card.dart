import 'package:flutter/material.dart';
import '../../data/models/zone.dart';

class ZoneCard extends StatelessWidget {
  final ConfluenceZone zone;
  final double currentPrice;

  const ZoneCard({
    super.key,
    required this.zone,
    required this.currentPrice,
  });

  @override
  Widget build(BuildContext context) {
    final isAbove = zone.mid > currentPrice;
    final diff = (zone.mid - currentPrice).abs();

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: zone.isStrong
            ? const Color(0xFFF59E0B).withOpacity(0.08)
            : const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: zone.isStrong ? const Color(0xFFF59E0B) : const Color(0xFF334155),
          width: zone.isStrong ? 1.5 : 1.0,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  if (zone.isStrong)
                    const Padding(
                      padding: EdgeInsets.only(right: 6),
                      child: Icon(Icons.star, color: Color(0xFFF59E0B), size: 18),
                    ),
                  Text(
                    '$${zone.low.toStringAsFixed(1)} - $${zone.high.toStringAsFixed(1)}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: zone.isStrong ? const Color(0xFFF59E0B) : Colors.white,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: zone.isStrong
                      ? const Color(0xFFF59E0B).withOpacity(0.2)
                      : const Color(0xFF334155),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  '${zone.levelCount} Confluent Levels',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: zone.isStrong ? const Color(0xFFF59E0B) : const Color(0xFF94A3B8),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            isAbove
                ? '+$${diff.toStringAsFixed(1)} above current price (Resistance)'
                : '-$${diff.toStringAsFixed(1)} below current price (Support)',
            style: TextStyle(
              fontSize: 12,
              color: isAbove ? const Color(0xFFF43F5E) : const Color(0xFF10B981),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: zone.levels.map((lvl) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F172A),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: const Color(0xFF475569)),
                ),
                child: Text(
                  '${lvl.id}: $${lvl.price.toStringAsFixed(1)}',
                  style: const TextStyle(fontSize: 11, color: Color(0xFFE2E8F0)),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
