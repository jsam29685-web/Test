import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/models/candle.dart';
import '../../data/models/scan_result.dart';
import '../../data/repositories/market_data_repository.dart';
import '../../domain/services/strategy_engine.dart';
import '../../core/services/notification_service.dart';
import 'settings_provider.dart';

class ScannerState {
  final bool isLoading;
  final ScanResult? scanResult;
  final List<Candle> candles;
  final List<ScanResult> history;
  final String? errorMessage;

  ScannerState({
    required this.isLoading,
    this.scanResult,
    this.candles = const [],
    this.history = const [],
    this.errorMessage,
  });

  ScannerState copyWith({
    bool? isLoading,
    ScanResult? scanResult,
    List<Candle>? candles,
    List<ScanResult>? history,
    String? errorMessage,
  }) {
    return ScannerState(
      isLoading: isLoading ?? this.isLoading,
      scanResult: scanResult ?? this.scanResult,
      candles: candles ?? this.candles,
      history: history ?? this.history,
      errorMessage: errorMessage,
    );
  }
}

class ScannerNotifier extends StateNotifier<ScannerState> {
  final Ref _ref;
  final MarketDataRepository _repository = MarketDataRepository();
  final StrategyEngine _engine = StrategyEngine();

  ScannerNotifier(this._ref) : super(ScannerState(isLoading: false)) {
    _loadCachedData();
  }

  Future<void> _loadCachedData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedJson = prefs.getString('last_scan_cache');
      final historyStrings = prefs.getStringList('scan_history') ?? [];

      ScanResult? cachedResult;
      if (cachedJson != null) {
        cachedResult = ScanResult.fromJson(jsonDecode(cachedJson) as Map<String, dynamic>);
      }

      final historyList = historyStrings
          .map((s) => ScanResult.fromJson(jsonDecode(s) as Map<String, dynamic>))
          .toList();

      state = state.copyWith(
        scanResult: cachedResult,
        history: historyList,
      );

      // Trigger fresh scan on open
      runScan();
    } catch (e) {
      // Fallback
    }
  }

  Future<void> runScan() async {
    state = state.copyWith(isLoading: true, errorMessage: null);

    try {
      final candles = await _repository.fetch15mCandles();
      if (candles.isEmpty) {
        state = state.copyWith(
          isLoading: false,
          errorMessage: 'Unable to connect to Coinbase/Binance servers. Check internet.',
        );
        return;
      }

      final settings = _ref.read(settingsProvider);
      final result = _engine.evaluate(
        candles: candles,
        filterSessions: settings.filterSessions,
        minRiskReward: settings.minRiskReward,
        maxSLinATR: settings.maxSLinATR,
      );

      // Persist to local cache
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('last_scan_cache', jsonEncode(result.toJson()));

      final updatedHistory = [result, ...state.history];
      if (updatedHistory.length > 20) updatedHistory.removeLast();
      await prefs.setStringList(
        'scan_history',
        updatedHistory.map((r) => jsonEncode(r.toJson())).toList(),
      );

      // Alert if TRADE
      if (result.verdict == 'TRADE' && result.signal != null) {
        await NotificationService.showTradeSignalNotification(result.signal!);
      }

      state = state.copyWith(
        isLoading: false,
        scanResult: result,
        candles: candles,
        history: updatedHistory,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Scan failed: ${e.toString()}',
      );
    }
  }
}

final scannerProvider = StateNotifierProvider<ScannerNotifier, ScannerState>((ref) {
  return ScannerNotifier(ref);
});
