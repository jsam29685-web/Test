import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../providers/scanner_provider.dart';

class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(scannerProvider);
    final history = state.history;
    final timeFormat = DateFormat('HH:mm:ss (dd MMM)');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan History (Last 20)'),
      ),
      body: history.isEmpty
          ? const Center(
              child: Text(
                'No scan history yet. Pull to refresh or wait for periodic background scan.',
                style: TextStyle(color: Color(0xFF94A3B8)),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: history.length,
              itemBuilder: (context, index) {
                final item = history[index];
                final isTrade = item.verdict == 'TRADE';

                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isTrade ? const Color(0xFF10B981) : const Color(0xFF334155),
                      width: isTrade ? 1.5 : 1.0,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: isTrade ? const Color(0xFF10B981) : const Color(0xFF64748B),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                isTrade
                                    ? 'TRADE SIGNAL: ${item.signal?.direction} ${item.signal?.setupType}'
                                    : 'NO TRADE',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: isTrade ? const Color(0xFF10B981) : const Color(0xFF94A3B8),
                                ),
                              ),
                            ],
                          ),
                          Text(
                            timeFormat.format(DateTime.fromMillisecondsSinceEpoch(item.timestamp)),
                            style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'BTC Price: $${item.currentPrice.toStringAsFixed(1)} | ATR: $${item.atr14.toStringAsFixed(1)} | Session: ${item.activeSession}',
                        style: const TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.reason,
                        style: const TextStyle(fontSize: 12, color: Colors.white70),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
